
function registerEvent(button) {
    alert("You have registered for the event!");
}
function saveEvent(button) {
    alert("Event saved to your list!");
}
function showSaved() {
    alert("Showing saved events...");
}
function showRegistered() {
    alert("Showing registered events...");
}
